# WeatherLens 🌦️

A clean, responsive real-time weather dashboard built with **HTML, CSS, and Vanilla JavaScript**.

## Features

- 🔍 Search weather for any city in the world
- 🌡️ Current temperature, feels-like, humidity, wind speed, visibility & pressure
- 📅 5-day weather forecast
- 🕓 Recent search history (saved in localStorage)
- 🌙 Dark / Light theme toggle (preference saved)
- 📱 Fully responsive — works on mobile, tablet & desktop

## Tech Stack

| Technology | Usage |
|---|---|
| HTML5 | Semantic structure |
| CSS3 | Custom properties, Grid, Flexbox, Animations |
| JavaScript (ES6+) | Fetch API, DOM manipulation, localStorage |
| OpenWeatherMap API | Live weather & forecast data |

## Setup Instructions

### Step 1 — Get a Free API Key
1. Go to [https://openweathermap.org/api](https://openweathermap.org/api)
2. Create a free account
3. Navigate to **API Keys** in your dashboard
4. Copy your key (it activates within ~2 hours of signup)

### Step 2 — Add Your API Key
Open `app.js` and replace line 4:
```js
const API_KEY = "YOUR_API_KEY_HERE";
```
with your actual key:
```js
const API_KEY = "abc123yourrealkeyhere";
```

### Step 3 — Run the Project
Simply open `index.html` in your browser. No build tools or npm needed!

> **Tip:** Use the [Live Server](https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer) VS Code extension for the best experience.

## Project Structure

```
weather-dashboard/
├── index.html   → App structure & layout
├── style.css    → All styles, themes & animations
├── app.js       → API calls, DOM logic, localStorage
└── README.md    → This file
```

## Key JavaScript Concepts Used

- `fetch()` with `async/await` for API calls
- JSON parsing and destructuring
- DOM manipulation (`createElement`, `innerHTML`, `textContent`)
- `localStorage` for persisting history and theme
- ES6+ features: template literals, arrow functions, spread operator
- Error handling with `try/catch`

## Live Demo

> Add your GitHub Pages link here after deploying

---

Made by **Sanyam Mittal**
