// ── CONFIG ──────────────────────────────────────────────────────────────────
// Get a FREE API key at: https://openweathermap.org/api
// Then replace the string below with your key.
const API_KEY = "YOUR_API_KEY_HERE";
const BASE_URL = "https://api.openweathermap.org/data/2.5";

// ── DOM REFS ─────────────────────────────────────────────────────────────────
const cityInput    = document.getElementById("cityInput");
const searchBtn    = document.getElementById("searchBtn");
const errorMsg     = document.getElementById("errorMsg");
const loader       = document.getElementById("loader");
const dashboard    = document.getElementById("dashboard");
const emptyState   = document.getElementById("emptyState");
const historyChips = document.getElementById("historyChips");
const themeToggle  = document.getElementById("themeToggle");
const themeIcon    = document.getElementById("themeIcon");

// Current weather elements
const cityName     = document.getElementById("cityName");
const countryName  = document.getElementById("countryName");
const dateTime     = document.getElementById("dateTime");
const weatherIcon  = document.getElementById("weatherIcon");
const temperature  = document.getElementById("temperature");
const feelsLike    = document.getElementById("feelsLike");
const description  = document.getElementById("description");
const humidity     = document.getElementById("humidity");
const wind         = document.getElementById("wind");
const visibility   = document.getElementById("visibility");
const pressure     = document.getElementById("pressure");
const forecastGrid = document.getElementById("forecastGrid");

// ── THEME ────────────────────────────────────────────────────────────────────
let currentTheme = localStorage.getItem("wl_theme") || "dark";
applyTheme(currentTheme);

themeToggle.addEventListener("click", () => {
  currentTheme = currentTheme === "dark" ? "light" : "dark";
  applyTheme(currentTheme);
  localStorage.setItem("wl_theme", currentTheme);
});

function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  themeIcon.textContent = theme === "dark" ? "☀️" : "🌙";
}

// ── SEARCH HISTORY ───────────────────────────────────────────────────────────
function getHistory() {
  return JSON.parse(localStorage.getItem("wl_history") || "[]");
}

function saveToHistory(city) {
  let history = getHistory();
  // Remove if already exists (avoid duplicates), then add to front
  history = history.filter(c => c.toLowerCase() !== city.toLowerCase());
  history.unshift(city);
  if (history.length > 6) history = history.slice(0, 6);
  localStorage.setItem("wl_history", JSON.stringify(history));
  renderHistoryChips();
}

function renderHistoryChips() {
  const history = getHistory();
  historyChips.innerHTML = "";
  history.forEach(city => {
    const chip = document.createElement("span");
    chip.className = "chip";
    chip.textContent = city;
    chip.addEventListener("click", () => {
      cityInput.value = city;
      fetchWeather(city);
    });
    historyChips.appendChild(chip);
  });
}

// ── HELPERS ──────────────────────────────────────────────────────────────────
function showError(msg) {
  errorMsg.textContent = msg;
}

function clearError() {
  errorMsg.textContent = "";
}

function showLoader() {
  loader.classList.remove("hidden");
  dashboard.classList.add("hidden");
  emptyState.style.display = "none";
}

function hideLoader() {
  loader.classList.add("hidden");
}

function formatDate(unixTimestamp) {
  const date = new Date(unixTimestamp * 1000);
  return date.toLocaleDateString("en-US", {
    weekday: "long", month: "long", day: "numeric", year: "numeric"
  });
}

function getDayName(unixTimestamp) {
  const date = new Date(unixTimestamp * 1000);
  return date.toLocaleDateString("en-US", { weekday: "short" });
}

function iconUrl(code) {
  return `https://openweathermap.org/img/wn/${code}@2x.png`;
}

// ── FETCH WEATHER ─────────────────────────────────────────────────────────────
async function fetchWeather(city) {
  if (!city.trim()) return;
  clearError();
  showLoader();

  try {
    // Current weather
    const currentRes = await fetch(
      `${BASE_URL}/weather?q=${encodeURIComponent(city)}&appid=${API_KEY}&units=metric`
    );

    if (!currentRes.ok) {
      if (currentRes.status === 404) throw new Error("City not found. Please check the spelling.");
      if (currentRes.status === 401) throw new Error("Invalid API key. See README to set up your key.");
      throw new Error("Something went wrong. Please try again.");
    }

    const current = await currentRes.json();

    // 5-day forecast
    const forecastRes = await fetch(
      `${BASE_URL}/forecast?q=${encodeURIComponent(city)}&appid=${API_KEY}&units=metric`
    );
    const forecast = await forecastRes.json();

    hideLoader();
    renderCurrentWeather(current);
    renderForecast(forecast);
    dashboard.classList.remove("hidden");
    saveToHistory(current.name);

  } catch (err) {
    hideLoader();
    emptyState.style.display = "block";
    showError(err.message);
  }
}

// ── RENDER CURRENT WEATHER ───────────────────────────────────────────────────
function renderCurrentWeather(data) {
  const { name, sys, dt, weather, main, wind: w, visibility: v } = data;

  cityName.textContent    = name;
  countryName.textContent = sys.country;
  dateTime.textContent    = formatDate(dt);
  weatherIcon.src         = iconUrl(weather[0].icon);
  weatherIcon.alt         = weather[0].description;
  temperature.textContent = Math.round(main.temp);
  feelsLike.textContent   = `Feels like ${Math.round(main.feels_like)}°C`;
  description.textContent = weather[0].description;
  humidity.textContent    = `${main.humidity}%`;
  wind.textContent        = `${(w.speed * 3.6).toFixed(1)} km/h`;
  visibility.textContent  = `${(v / 1000).toFixed(1)} km`;
  pressure.textContent    = `${main.pressure} hPa`;
}

// ── RENDER FORECAST ──────────────────────────────────────────────────────────
function renderForecast(data) {
  // API returns data every 3 hours — pick one entry per day (around 12:00)
  const daily = {};
  data.list.forEach(item => {
    const date = new Date(item.dt * 1000);
    const dayKey = date.toDateString();
    const hour   = date.getHours();
    // Prefer noon reading
    if (!daily[dayKey] || Math.abs(hour - 12) < Math.abs(new Date(daily[dayKey].dt * 1000).getHours() - 12)) {
      daily[dayKey] = item;
    }
  });

  const days = Object.values(daily).slice(0, 5);
  forecastGrid.innerHTML = "";

  days.forEach(day => {
    const { dt, weather, main } = day;
    const card = document.createElement("div");
    card.className = "forecast-card";
    card.innerHTML = `
      <div class="forecast-day">${getDayName(dt)}</div>
      <img class="forecast-icon" src="${iconUrl(weather[0].icon)}" alt="${weather[0].description}" />
      <div class="forecast-temp-high">${Math.round(main.temp_max)}°C</div>
      <div class="forecast-temp-low">${Math.round(main.temp_min)}°C</div>
      <div class="forecast-desc">${weather[0].description}</div>
    `;
    forecastGrid.appendChild(card);
  });
}

// ── EVENT LISTENERS ──────────────────────────────────────────────────────────
searchBtn.addEventListener("click", () => fetchWeather(cityInput.value));

cityInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") fetchWeather(cityInput.value);
});

// ── INIT ─────────────────────────────────────────────────────────────────────
renderHistoryChips();
